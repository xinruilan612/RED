# 有迹风洞验证准备包

本包含待办、执行指南、公开许可候选、空研究表格、校验工具与测试证据；不是软件安装包，也不含真实模型或真人研究结果。

仅供研究负责人使用，含盲号映射，不能整包发给读者。

在解压根目录执行：

```sh
python3 scripts/windtunnel_study.py init --output-dir /绝对路径/private-study
python3 scripts/windtunnel_study.py inspect --study-dir /绝对路径/private-study --output /绝对路径/private-study/readiness.json
```

准备未齐时 inspect 退出码为2；真实模型预算、探索后冻结、最终两版和真人同意仍需实际取得。目标和报告文件拒绝覆盖。

仅在全部记录齐全时运行 pack，输出每位读者自己的空问卷、任务和盲稿；工具不会发送消息或调用模型。

软件本体仍在原项目。详细入口见 docs/windtunnel/EXECUTION_GUIDE.md。
