# 风洞修复与完整复测资料

本机原项目已经直接修改，无需把本包解压覆盖项目。
先读 docs/windtunnel/agent_study/revision5/REPORT.md，历史失败、全部开发回归、原始模型响应和18次新代理盲评都保留。

本包是实测证据与源码参考，不是安装程序。正式运行仍用原项目的 scripts/local_dev.py 与 docs/DEPLOYMENT.md；请勿误把已付费研究脚本当作一键启动器。

免费复核证据：在本目录运行 `PYTHONPATH=tests python3 -m unittest test_agent_study_evidence test_windtunnel_repair_evidence -v`。不需要模型密钥，不发模型请求。

162次累计实际模型请求，费用上界含未知预留2.118922元，未超过5元。代理原删节0/45、修复32/45，完整题均0/9；不代表真人效果、普通AI优势或传播效果。

不包含数据库、环境密钥、账户余额、真实身份或发布凭据。
